const socket = io();

const podium = document.querySelector('#podium');

const urlParameters = new URLSearchParams(window.location.search);

const showDetailedStats = urlParameters.get('detailed') === 'true';

let podiumCanvas = null;
let podiumContext = null;
let animationFrameId = null;

let currentPlayers = [];
let currentMode = 'classic';

let podiumSettings = {
    podiumLimit: 10,
    podiumFontFamily: 'Verdana',
    podiumFontSize: 26,
    podiumFontWeight: '700',
    podiumTextColor: '#ffffff',
    podiumTitleColor: '#ffe66d',
    podiumWinsColor: '#ffe66d',
    podiumTitleSize: 32
};

function getDisplayName(player) {
    return player.nickname || player.username || player.uniqueId || 'viewer';
}

function getNumber(value, fallback) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
}

function getPlayerColorConfig(player) {
    const customColor = player?.customColor;
    if (!customColor || typeof customColor !== 'object') {
        return { type: 'solid', color1: podiumSettings.podiumTextColor || '#ffffff', color2: null };
    }
    return {
        type: customColor.type || 'solid',
        color1: customColor.color1 || podiumSettings.podiumTextColor || '#ffffff',
        color2: customColor.color2 || null
    };
}

function getModeLabel(mode) {
    return mode === 'battle' ? 'Batalla' : 'Clásico';
}

function getFont(size, weight, family) {
    return `${weight} ${size}px ${family}`;
}

function resizePodiumCanvas() {
    if (!podiumCanvas || !podiumContext) return;

    const width = Math.max(320, podium.clientWidth || 800);
    const height = Math.max(240, podium.clientHeight || 600);
    const pixelRatio = window.devicePixelRatio || 1;

    podiumCanvas.width = Math.floor(width * pixelRatio);
    podiumCanvas.height = Math.floor(height * pixelRatio);
    podiumCanvas.style.width = `${width}px`;
    podiumCanvas.style.height = `${height}px`;

    podiumContext.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    drawPodium();
}

function drawRoundedRect(context, x, y, width, height, radius, fillStyle) {
    context.beginPath();
    if (typeof context.roundRect === 'function') {
        context.roundRect(x, y, width, height, radius);
    } else {
        context.moveTo(x + radius, y);
        context.lineTo(x + width - radius, y);
        context.quadraticCurveTo(x + width, y, x + width, y + radius);
        context.lineTo(x + width, y + height - radius);
        context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        context.lineTo(x + radius, y + height);
        context.quadraticCurveTo(x, y + height, x, y + height - radius);
        context.lineTo(x, y + radius);
        context.quadraticCurveTo(x, y, x + radius, y);
    }
    context.fillStyle = fillStyle;
    context.fill();
}

function drawText(context, text, x, y, font, color, align = 'left') {
    context.font = font;
    context.textAlign = align;
    context.textBaseline = 'middle';
    context.fillStyle = color;
    context.fillText(text, x, y);
}

function drawPlayerName(player, x, y, maxWidth) {
    const context = podiumContext;
    const config = getPlayerColorConfig(player);
    const fontSize = getNumber(podiumSettings.podiumFontSize, 26);
    const fontWeight = podiumSettings.podiumFontWeight || '700';
    const fontFamily = podiumSettings.podiumFontFamily || 'Verdana';
    const font = getFont(fontSize, fontWeight, fontFamily);
    const name = getDisplayName(player);

    context.save();
    context.font = font;
    context.textAlign = 'left';
    context.textBaseline = 'middle';

    const textMetrics = context.measureText(name);
    const textWidth = Math.max(textMetrics.width, 1);

    if (config.type === 'rainbow') {
        const time = Date.now() / 20;
        const gradient = context.createLinearGradient(x, y, x + textWidth, y);
        for (let index = 0; index <= 6; index += 1) {
            const hue = (time + index * 60) % 360;
            gradient.addColorStop(index / 6, `hsl(${hue}, 100%, 50%)`);
        }
        context.fillStyle = gradient;
    } else if (config.type === 'gradient' && config.color1 && config.color2) {
        const gradient = context.createLinearGradient(x, y, x + textWidth, y);
        gradient.addColorStop(0, config.color1);
        gradient.addColorStop(1, config.color2);
        context.fillStyle = gradient;
    } else {
        context.fillStyle = config.color1 || '#ffffff';
    }

    context.fillText(name, x, y);
    context.restore();
}

function drawPodium() {
    if (!podiumCanvas || !podiumContext) return;

    const context = podiumContext;
    const width = podiumCanvas.clientWidth || 800;
    const height = podiumCanvas.clientHeight || 600;

    // Background
    context.fillStyle = 'rgba(0, 0, 0, 0.58)';
    context.fillRect(0, 0, width, height);

    const titleSize = getNumber(podiumSettings.podiumTitleSize, 32);
    const titleFont = getFont(titleSize, '700', podiumSettings.podiumFontFamily || 'Verdana');

    drawText(
        context,
        `🏆 Podio histórico - ${getModeLabel(currentMode)}`,
        width / 2,
        titleSize + 20,
        titleFont,
        podiumSettings.podiumTitleColor || '#ffe66d',
        'center'
    );

    const limit = Math.max(1, Math.floor(getNumber(podiumSettings.podiumLimit, 10)));
    const players = currentPlayers.slice(0, limit);

    const rowHeight = 48;
    const firstRowY = titleSize + 70;
    const positionWidth = 54;
    const statsWidth = 260;
    const nameX = positionWidth + 24;
    const nameWidth = Math.max(120, width - nameX - statsWidth - 24);

    players.forEach((player, index) => {
        const y = firstRowY + index * rowHeight;

        if (index % 2 === 0) {
            drawRoundedRect(
                context,
                8,
                y - rowHeight / 2 + 2,
                width - 16,
                rowHeight - 4,
                8,
                'rgba(255, 255, 255, 0.06)'
            );
        }

        drawText(
            context,
            `${index + 1}.`,
            positionWidth / 2,
            y,
            getFont(22, '700', podiumSettings.podiumFontFamily || 'Verdana'),
            podiumSettings.podiumWinsColor || '#ffe66d',
            'center'
        );

        drawPlayerName(player, nameX, y, nameWidth);

        const winsText = `${player.wins || 0} 🏆`;
        drawText(
            context,
            winsText,
            width - 18,
            y,
            getFont(18, '700', podiumSettings.podiumFontFamily || 'Verdana'),
            podiumSettings.podiumWinsColor || '#ffe66d',
            'right'
        );
    });
}

function startPodiumAnimation() {
    if (animationFrameId !== null) return;

    function animate() {
        drawPodium();
        animationFrameId = requestAnimationFrame(animate);
    }

    animationFrameId = requestAnimationFrame(animate);
}

function setupPodiumCanvas() {
    podium.innerHTML = '';

    podiumCanvas = document.createElement('canvas');
    podiumCanvas.id = 'podium-canvas';
    podiumCanvas.style.display = 'block';
    podiumCanvas.style.width = '100%';
    podiumCanvas.style.height = '100%';

    podium.appendChild(podiumCanvas);
    podiumContext = podiumCanvas.getContext('2d');

    resizePodiumCanvas();
    startPodiumAnimation();
}

function handleState(state) {
    if (!state) return;

    podiumSettings = { ...podiumSettings, ...(state.settings || {}) };
    const game = state.game || {};
    currentMode = game.podiumMode === 'battle' ? 'battle' : 'classic';
    currentPlayers = game.podium || [];

    drawPodium();
}

setupPodiumCanvas();
window.addEventListener('resize', resizePodiumCanvas);

socket.on('state:init', handleState);
socket.on('state:update', handleState);
socket.on('state', handleState);