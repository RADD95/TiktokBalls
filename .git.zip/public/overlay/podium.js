const socket =
    io();

const podium =
    document.querySelector(
        '#podium'
    );

function getDisplayName(player) {
    return (
        player.nickname ||
        player.username ||
        player.uniqueId ||
        'viewer'
    );
}

function renderPodium(players) {
    podium.innerHTML =
        '';

    const panel =
        document.createElement(
            'section'
        );

    panel.className =
        'podium-panel';

    const title =
        document.createElement(
            'h1'
        );

    title.className =
        'podium-title';

    title.textContent =
        '🏆 Podio histórico';

    panel.appendChild(
        title
    );

    players
        .slice(0, 10)
        .forEach(
            (player, index) => {
                const row =
                    document.createElement(
                        'div'
                    );

                row.className =
                    'podium-row';

                const position =
                    document.createElement(
                        'span'
                    );

                position.className =
                    'podium-position';

                position.textContent =
                    `${index + 1}.`;

                const name =
                    document.createElement(
                        'span'
                    );

                name.className =
                    'podium-name';

                name.textContent =
                    getDisplayName(
                        player
                    );

                const wins =
                    document.createElement(
                        'span'
                    );

                wins.className =
                    'podium-wins';

                wins.textContent =
                    `${player.wins || 0} 🏆`;

                row.appendChild(
                    position
                );

                row.appendChild(
                    name
                );

                row.appendChild(
                    wins
                );

                panel.appendChild(
                    row
                );
            }
        );

    podium.appendChild(
        panel
    );
}

function handleState(state) {
    if (!state) {
        return;
    }

    const game =
        state.game || {};

    renderPodium(
        game.podium || []
    );
}

socket.on(
    'state:init',
    handleState
);

socket.on(
    'state:update',
    handleState
);

socket.on(
    'state',
    handleState
);