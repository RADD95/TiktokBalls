const socket =
    io();

const ranking =
    document.querySelector(
        '#ranking'
    );

function getDisplayName(player) {
    return (
        player.nickname ||
        player.username ||
        player.uniqueId ||
        'viewer'
    );
}

function renderRanking(players) {
    ranking.innerHTML =
        '';

    const panel =
        document.createElement(
            'section'
        );

    panel.className =
        'ranking-panel';

    const title =
        document.createElement(
            'h1'
        );

    title.className =
        'ranking-title';

    title.textContent =
        'Ranking';

    panel.appendChild(
        title
    );

    const sortedPlayers =
        [...players]
            .sort(
                (first, second) =>
                    Number(
                        second.points || 0
                    ) -
                    Number(
                        first.points || 0
                    )
            )
            .slice(0, 10);

    sortedPlayers.forEach(
        (player, index) => {
            const row =
                document.createElement(
                    'div'
                );

            row.className =
                'ranking-row';

            const position =
                document.createElement(
                    'span'
                );

            position.className =
                'ranking-position';

            position.textContent =
                `${index + 1}.`;

            const name =
                document.createElement(
                    'span'
                );

            name.className =
                'ranking-name';

            name.textContent =
                getDisplayName(
                    player
                );

            const points =
                document.createElement(
                    'span'
                );

            points.className =
                'ranking-points';

            points.textContent =
                Math.floor(
                    Number(
                        player.points || 0
                    )
                );

            row.appendChild(
                position
            );

            row.appendChild(
                name
            );

            row.appendChild(
                points
            );

            panel.appendChild(
                row
            );
        }
    );

    ranking.appendChild(
        panel
    );
}

function handleState(state) {
    if (!state) {
        return;
    }

    renderRanking(
        state.players || []
    );
}

socket.on(
    'state:init',
    handleState
);

socket.on(
    'state:update',
    handleState
);

socket.on(
    'state',
    handleState
);